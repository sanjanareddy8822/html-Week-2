# CodeCraft — HTML & CSS Week 2 Project

A responsive HTML/CSS learning showcase created for the Week 2 assignment.

## Features

- Semantic HTML5 structure
- Responsive navigation
- Hero section and call-to-action buttons
- CSS Grid and Flexbox layouts
- Responsive image-style gallery built with CSS gradients
- Form with focus states
- CSS transforms and keyframe animation
- Mobile, tablet and desktop breakpoints
- No JavaScript or framework required

## Project structure

```text
html-css-week2-project/
├── index.html
├── style.css
├── README.md
└── assets/
```

## How to run

Open `index.html` in a browser, or use VS Code Live Server.

## Course reference

This project is an original educational implementation inspired by the concepts covered in Bro Code's
“HTML & CSS Full Course for free” YouTube course:
https://youtu.be/HGTJBPNC-Gw

The linked course covers HTML basics through CSS layouts, navigation, image galleries, Flexbox,
transforms and animations.

## GitHub

Create a repository, then upload all files in this folder.

Example:

```bash
git init
git add .
git commit -m "Complete HTML CSS Week 2 project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## Note

This is an original project made to demonstrate the course concepts; it is not a copy of the
instructor's source code.
